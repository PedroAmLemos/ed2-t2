#ifndef TREATMENT_H_
#define TREATMENT_H_
#include <stdio.h>

// geoFile, qryFile, geoSVGFile, qrySVGFile, qryTXTFile, viaFile,
void main_treatment(FILE *geoFile, FILE *qryFile, FILE *viaFile, FILE *geoSVGFile, FILE *qrySVGFile, FILE * qryTXTFile);

#endif
